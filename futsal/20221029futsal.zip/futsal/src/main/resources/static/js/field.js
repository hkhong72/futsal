$(document).ready(function(){
	var fName = $("#fName").val();
	console.log("자바스크립트 필드명 : " + $("#fName").val())
	
})